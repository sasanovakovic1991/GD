# Građevinski dnevnik (PWA)

Jednostavna PWA aplikacija za dnevnik gradilišta: evidencija radnika i strojeva, zaključavanje dana, admin izvještaji, PDF i Excel backup. Radi **offline** (IndexedDB + Service Worker).

## PIN-ovi (default)
- Administrator: **852456**
- Voditelj gradilišta: **123321**

## Deploy na GitHub Pages
1. Napravi repo i uploadaj sve datoteke iz ovog paketa (root).
2. U repo **Settings → Pages** postavi **Branch: main** i **/ (root)**.
3. Otvori URL oblika: `https://USERNAME.github.io/REPO/`

## Vlastita domena
- DNS A-zapisi (za apex): `185.199.108.153`, `185.199.109.153`, `185.199.110.153`, `185.199.111.153`
- (Opcionalno) CNAME za `www` → `USERNAME.github.io`
- U **Settings → Pages → Custom domain** upiši svoju domenu (npr. `dnevnik.moja-domena.hr`).

## PWA
- `manifest.json` + `sw.js`
- Aplikacija se može instalirati na mobitel (Add to Home Screen)

## Backup
- Admin → Izvještaji → **💾 Excel backup (dnevnici)**

## Struktura podataka (IndexedDB)
- `users` ({id, role, pinHash})
- `sites` ({id, name, location})
- `workers` ({id, name, role})
- `equipment` ({id, name, kind})
- `rates` ({id, entityType, sell, cost})  // prodajna i nabavna €/h
- `logs` ({id, date, siteId, workers:[{id,name,hours}], equipment:[{id,name,hours}], note, locked})

## Lokalni test
- Otvori `index.html` u pregledniku ili koristi **Live Server** (VS Code).
- provjeri **Application → Service Workers** (DevTools) da je SW registriran.
